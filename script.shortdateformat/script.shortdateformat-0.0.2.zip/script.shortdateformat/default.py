from datetime import date
import xbmc, xbmcgui

format = xbmc.getRegion('dateshort')

notify = xbmcgui.Dialog().notification
notify(format, date.today().strftime(format), time=20000)
    

 
